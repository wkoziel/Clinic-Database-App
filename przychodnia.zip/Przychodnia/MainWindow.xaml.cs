﻿using Przychodnia.DAL;
using Przychodnia.DAL.Repozytoria;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Przychodnia
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            FillTabsComboBox();
           // try
            //{
                DoctorRepo.GetAllDoctors();
           // }
           // catch { }
            //Testowo wyświetla w outpucie zawartość tabeli lekarze - test poprawności połączenia z bazą
        }

        //Wypełnia ComboBox nazwami tabel
        void FillTabsComboBox()
        {
            TabsComboBox.Items.Add("Wizyty");
            TabsComboBox.Items.Add("Pacjenci");
            TabsComboBox.Items.Add("Lekarze");
            TabsComboBox.Items.Add("Sale");
            TabsComboBox.Items.Add("Poradnie");
            TabsComboBox.Items.Add("Przydział Lekarzy");
            TabsComboBox.Items.Refresh();
        }

        private void ChangeTableComboBox(object sender, SelectionChangedEventArgs e)
        {
            //Funkcja zmieniająca tabele w zależności od wybranej w combobox
        }
    }
}
